package vn.dang.callguard

import org.json.JSONArray
import org.json.JSONObject

/** Chuẩn hoá số, nhận diện đầu số Việt Nam và quyết định chặn/cảnh báo (giống hệt engine.js). */
object Engine {

    data class Info(val type: String, val label: String, val carrier: String? = null, val area: String? = null, val code: String? = null)
    data class Decision(val action: String, val reason: String, val info: Info)

    private val MOBILE = linkedMapOf(
        "Viettel" to listOf("086", "096", "097", "098", "032", "033", "034", "035", "036", "037", "038", "039"),
        "MobiFone" to listOf("089", "090", "093", "070", "076", "077", "078", "079"),
        "VinaPhone" to listOf("088", "091", "094", "081", "082", "083", "084", "085"),
        "Vietnamobile" to listOf("092", "052", "056", "058"),
        "Gmobile" to listOf("099", "059"),
        "iTel" to listOf("087"),
        "Reddi" to listOf("055"),
    )

    private val LANDLINE = mapOf(
        "024" to "Hà Nội", "028" to "TP. Hồ Chí Minh",
        "0203" to "Quảng Ninh", "0204" to "Bắc Giang", "0205" to "Lạng Sơn", "0206" to "Cao Bằng", "0207" to "Tuyên Quang",
        "0208" to "Thái Nguyên", "0209" to "Bắc Kạn", "0210" to "Phú Thọ", "0211" to "Vĩnh Phúc", "0212" to "Sơn La",
        "0213" to "Lai Châu", "0214" to "Lào Cai", "0215" to "Điện Biên", "0216" to "Yên Bái", "0218" to "Hòa Bình",
        "0219" to "Hà Giang", "0220" to "Hải Dương", "0221" to "Hưng Yên", "0222" to "Bắc Ninh", "0225" to "Hải Phòng",
        "0226" to "Hà Nam", "0227" to "Thái Bình", "0228" to "Nam Định", "0229" to "Ninh Bình", "0232" to "Quảng Bình",
        "0233" to "Quảng Trị", "0234" to "Huế", "0235" to "Quảng Nam", "0236" to "Đà Nẵng", "0237" to "Thanh Hóa",
        "0238" to "Nghệ An", "0239" to "Hà Tĩnh", "0251" to "Đồng Nai", "0252" to "Bình Thuận", "0254" to "Bà Rịa - Vũng Tàu",
        "0255" to "Quảng Ngãi", "0256" to "Bình Định", "0257" to "Phú Yên", "0258" to "Khánh Hòa", "0259" to "Ninh Thuận",
        "0260" to "Kon Tum", "0261" to "Đắk Nông", "0262" to "Đắk Lắk", "0263" to "Lâm Đồng", "0269" to "Gia Lai",
        "0270" to "Vĩnh Long", "0271" to "Bình Phước", "0272" to "Long An", "0273" to "Tiền Giang", "0274" to "Bình Dương",
        "0275" to "Bến Tre", "0276" to "Tây Ninh", "0277" to "Đồng Tháp", "0290" to "Cà Mau", "0291" to "Bạc Liêu",
        "0292" to "Cần Thơ", "0293" to "Hậu Giang", "0294" to "Trà Vinh", "0296" to "An Giang", "0297" to "Kiên Giang",
        "0299" to "Sóc Trăng",
    )

    fun normalize(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        var s = raw.trim().replace(Regex("[^\\d+]"), "")
        if (s.startsWith("00")) s = "+" + s.substring(2)
        if (s.startsWith("+84")) s = "0" + s.substring(3)
        else if (Regex("^84\\d{9,10}$").matches(s)) s = "0" + s.substring(2)
        return s
    }

    fun identify(raw: String?): Info {
        val n = normalize(raw)
        if (n.isEmpty()) return Info("hidden", "Số ẩn / riêng tư")
        if (n.startsWith("+")) return Info("intl", "Số nước ngoài")
        if (n.startsWith("1900")) return Info("service", "Tổng đài dịch vụ (tính phí)")
        if (n.startsWith("1800")) return Info("service", "Tổng đài miễn phí")
        if (n.startsWith("02")) {
            val code = if (n.length >= 3 && LANDLINE.containsKey(n.take(3))) n.take(3) else n.take(4)
            val area = LANDLINE[code]
            return Info("landline", if (area != null) "Máy bàn $area" else "Máy bàn", area = area, code = code)
        }
        val p3 = n.take(3)
        for ((carrier, list) in MOBILE) if (p3 in list) return Info("mobile", "Di động $carrier", carrier = carrier)
        return Info("unknown", "Không xác định")
    }

    fun format(raw: String?): String {
        val n = normalize(raw)
        if (n.isEmpty()) return "Số ẩn"
        if (n.startsWith("+")) return n
        return when {
            Regex("^0(24|28)\\d{8}$").matches(n) -> "${n.substring(0, 3)} ${n.substring(3, 7)} ${n.substring(7)}"
            Regex("^02\\d{9}$").matches(n) || Regex("^0\\d{9}$").matches(n) -> "${n.substring(0, 4)} ${n.substring(4, 7)} ${n.substring(7)}"
            Regex("^1[89]00\\d+$").matches(n) -> "${n.substring(0, 4)} ${n.substring(4)}"
            else -> n
        }
    }

    private fun findIn(arr: JSONArray?, n: String): JSONObject? {
        arr ?: return null
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (normalize(o.optString("number")) == n) return o
        }
        return null
    }

    /** Thứ tự ưu tiên giống engine.js: số ẩn → cho phép → danh bạ → danh sách chặn → quy tắc đầu số → nước ngoài → chặn mọi số lạ → cảnh báo */
    fun decide(raw: String?, contactName: String?, cfg: JSONObject): Decision {
        val n = normalize(raw)
        val info = identify(raw)
        if (n.isEmpty()) {
            return when {
                cfg.optBoolean("blockHidden") -> Decision("block", "Chặn số ẩn", info)
                cfg.optBoolean("warnUnknown", true) -> Decision("warn", "Số ẩn danh", info)
                else -> Decision("allow", "", info)
            }
        }
        findIn(cfg.optJSONArray("whitelist"), n)?.let {
            val l = it.optString("label")
            return Decision("allow", "Danh sách cho phép" + if (l.isNotEmpty()) ": $l" else "", info)
        }
        if (!contactName.isNullOrEmpty()) return Decision("allow", "Có trong danh bạ", info)
        findIn(cfg.optJSONArray("blacklist"), n)?.let {
            val l = it.optString("label")
            return Decision("block", "Số trong danh sách chặn" + if (l.isNotEmpty()) ": $l" else "", info)
        }
        val rules = cfg.optJSONArray("rules") ?: JSONArray()
        for (i in 0 until rules.length()) {
            val r = rules.optJSONObject(i) ?: continue
            if (!r.optBoolean("on")) continue
            val label = r.optString("label")
            when (r.optString("type")) {
                "landline_all" -> if (info.type == "landline") return Decision("block", "Quy tắc: $label", info)
                "prefix" -> {
                    val v = normalize(r.optString("value"))
                    if (v.isNotEmpty() && n.startsWith(v))
                        return Decision("block", "Quy tắc: " + label.ifEmpty { "Đầu số $v" }, info)
                }
            }
        }
        if (info.type == "intl" && cfg.optBoolean("blockIntl")) return Decision("block", "Chặn số nước ngoài", info)
        if (cfg.optBoolean("blockAllUnknown") && !(cfg.optBoolean("allowServices", true) && info.type == "service"))
            return Decision("block", "Chặn mọi số không có trong danh bạ", info)
        if (cfg.optBoolean("warnUnknown", true)) return Decision("warn", "Không có trong danh bạ", info)
        return Decision("allow", "", info)
    }
}
