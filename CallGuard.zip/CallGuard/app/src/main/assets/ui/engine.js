/* CallGuard engine – chuẩn hoá số, nhận diện đầu số Việt Nam, quyết định chặn/cảnh báo.
   Logic này sẽ được viết lại y hệt bằng Kotlin trong CallScreeningService của app Android. */
(function () {
  'use strict';

  const MOBILE = {
    Viettel: ['086', '096', '097', '098', '032', '033', '034', '035', '036', '037', '038', '039'],
    MobiFone: ['089', '090', '093', '070', '076', '077', '078', '079'],
    VinaPhone: ['088', '091', '094', '081', '082', '083', '084', '085'],
    Vietnamobile: ['092', '052', '056', '058'],
    Gmobile: ['099', '059'],
    iTel: ['087'],
    Reddi: ['055'],
  };
  const LANDLINE = {
    '024': 'Hà Nội', '028': 'TP. Hồ Chí Minh',
    '0203': 'Quảng Ninh', '0204': 'Bắc Giang', '0205': 'Lạng Sơn', '0206': 'Cao Bằng', '0207': 'Tuyên Quang',
    '0208': 'Thái Nguyên', '0209': 'Bắc Kạn', '0210': 'Phú Thọ', '0211': 'Vĩnh Phúc', '0212': 'Sơn La',
    '0213': 'Lai Châu', '0214': 'Lào Cai', '0215': 'Điện Biên', '0216': 'Yên Bái', '0218': 'Hòa Bình',
    '0219': 'Hà Giang', '0220': 'Hải Dương', '0221': 'Hưng Yên', '0222': 'Bắc Ninh', '0225': 'Hải Phòng',
    '0226': 'Hà Nam', '0227': 'Thái Bình', '0228': 'Nam Định', '0229': 'Ninh Bình', '0232': 'Quảng Bình',
    '0233': 'Quảng Trị', '0234': 'Huế', '0235': 'Quảng Nam', '0236': 'Đà Nẵng', '0237': 'Thanh Hóa',
    '0238': 'Nghệ An', '0239': 'Hà Tĩnh', '0251': 'Đồng Nai', '0252': 'Bình Thuận', '0254': 'Bà Rịa - Vũng Tàu',
    '0255': 'Quảng Ngãi', '0256': 'Bình Định', '0257': 'Phú Yên', '0258': 'Khánh Hòa', '0259': 'Ninh Thuận',
    '0260': 'Kon Tum', '0261': 'Đắk Nông', '0262': 'Đắk Lắk', '0263': 'Lâm Đồng', '0269': 'Gia Lai',
    '0270': 'Vĩnh Long', '0271': 'Bình Phước', '0272': 'Long An', '0273': 'Tiền Giang', '0274': 'Bình Dương',
    '0275': 'Bến Tre', '0276': 'Tây Ninh', '0277': 'Đồng Tháp', '0290': 'Cà Mau', '0291': 'Bạc Liêu',
    '0292': 'Cần Thơ', '0293': 'Hậu Giang', '0294': 'Trà Vinh', '0296': 'An Giang', '0297': 'Kiên Giang',
    '0299': 'Sóc Trăng',
  };

  /** Chuẩn hoá: bỏ khoảng trắng/dấu; +84 / 84 -> 0; giữ dấu + cho số nước ngoài */
  function normalize(raw) {
    if (!raw) return '';
    let s = String(raw).trim().replace(/[^\d+]/g, '');
    if (s.startsWith('00')) s = '+' + s.slice(2);
    if (s.startsWith('+84')) s = '0' + s.slice(3);
    else if (/^84\d{9,10}$/.test(s)) s = '0' + s.slice(2);
    return s;
  }

  function identify(raw) {
    const n = normalize(raw);
    if (!n) return { type: 'hidden', label: 'Số ẩn / riêng tư', icon: '🕶️' };
    if (n.startsWith('+')) return { type: 'intl', label: 'Số nước ngoài', icon: '🌐' };
    if (n.startsWith('1900')) return { type: 'service', label: 'Tổng đài dịch vụ (tính phí)', icon: '☎️' };
    if (n.startsWith('1800')) return { type: 'service', label: 'Tổng đài miễn phí', icon: '☎️' };
    if (n.startsWith('02')) {
      const code = LANDLINE[n.slice(0, 3)] ? n.slice(0, 3) : n.slice(0, 4);
      const area = LANDLINE[code];
      return { type: 'landline', label: area ? `Máy bàn ${area}` : 'Máy bàn', area, code, icon: '🏢' };
    }
    const p3 = n.slice(0, 3);
    for (const [carrier, list] of Object.entries(MOBILE)) {
      if (list.includes(p3)) return { type: 'mobile', label: `Di động ${carrier}`, carrier, icon: '📱' };
    }
    return { type: 'unknown', label: 'Không xác định', icon: '❔' };
  }

  function format(raw) {
    const n = normalize(raw);
    if (!n) return 'Số ẩn';
    if (n.startsWith('+')) return n;
    if (/^0(24|28)\d{8}$/.test(n)) return `${n.slice(0, 3)} ${n.slice(3, 7)} ${n.slice(7)}`;
    if (/^02\d{9}$/.test(n)) return `${n.slice(0, 4)} ${n.slice(4, 7)} ${n.slice(7)}`;
    if (/^0\d{9}$/.test(n)) return `${n.slice(0, 4)} ${n.slice(4, 7)} ${n.slice(7)}`;
    if (/^1[89]00\d+$/.test(n)) return `${n.slice(0, 4)} ${n.slice(4)}`;
    return n;
  }

  /**
   * Quyết định cho 1 cuộc gọi đến.
   * cfg: { blockHidden, blockIntl, blockAllUnknown, warnUnknown, allowServices,
   *        rules:[{id,type:'prefix'|'landline_all',value,label,on}], whitelist:[{number,label}], blacklist:[{number,label}] }
   * contactName: tên trong danh bạ hoặc null
   * Trả về { action: 'allow'|'warn'|'block', reason, info }
   */
  function decide(raw, contactName, cfg) {
    const n = normalize(raw);
    const info = identify(raw);
    if (!n) return cfg.blockHidden ? { action: 'block', reason: 'Chặn số ẩn', info } : (cfg.warnUnknown ? { action: 'warn', reason: 'Số ẩn danh', info } : { action: 'allow', reason: '', info });
    const wl = cfg.whitelist.find((x) => normalize(x.number) === n);
    if (wl) return { action: 'allow', reason: `Danh sách cho phép${wl.label ? ': ' + wl.label : ''}`, info };
    if (contactName) return { action: 'allow', reason: 'Có trong danh bạ', info, contactName };
    const bl = cfg.blacklist.find((x) => normalize(x.number) === n);
    if (bl) return { action: 'block', reason: `Số trong danh sách chặn${bl.label ? ': ' + bl.label : ''}`, info };
    for (const r of cfg.rules) {
      if (!r.on) continue;
      if (r.type === 'landline_all' && info.type === 'landline') return { action: 'block', reason: `Quy tắc: ${r.label}`, info, ruleId: r.id };
      if (r.type === 'prefix' && n.startsWith(normalize(r.value))) return { action: 'block', reason: `Quy tắc: ${r.label || 'Đầu số ' + r.value}`, info, ruleId: r.id };
    }
    if (info.type === 'intl' && cfg.blockIntl) return { action: 'block', reason: 'Chặn số nước ngoài', info };
    if (cfg.blockAllUnknown && !(cfg.allowServices && info.type === 'service')) return { action: 'block', reason: 'Chặn mọi số không có trong danh bạ', info };
    if (cfg.warnUnknown) return { action: 'warn', reason: 'Không có trong danh bạ', info };
    return { action: 'allow', reason: '', info };
  }

  window.Engine = { normalize, identify, format, decide, LANDLINE, MOBILE };
})();
