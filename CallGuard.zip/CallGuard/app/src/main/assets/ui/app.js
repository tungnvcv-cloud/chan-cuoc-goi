/* Chặn Cuộc Gọi – giao diện (bản xem trước dùng danh bạ mẫu + giả lập cuộc gọi) */
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const E = window.Engine;
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  const native = window.Android || null;   // có trong app Android, không có ở bản xem trước
  if (native) {
    document.getElementById('previewBanner').remove();
    const simCard = document.getElementById('simInput').closest('.card');
    simCard.querySelector('.card-title').textContent = '🧪 Thử quy tắc';
    simCard.querySelector('.card-sub').textContent = 'Mô phỏng một cuộc gọi đến để xem app sẽ xử lý thế nào (không ghi vào nhật ký)';
  }

  // ---------- Dữ liệu mẫu (bản xem trước) ----------
  const CONTACTS = [
    { name: 'Mẹ', number: '0912345678' },
    { name: 'Anh Hùng – kế toán', number: '0987654321' },
    { name: 'Chị Lan', number: '0903111222' },
    { name: 'Công ty ABC (lễ tân)', number: '02438123456' },
  ];
  let cfg = {
    warnUnknown: true, blockHidden: false, blockIntl: false, blockAllUnknown: false, allowServices: true,
    notifyBlocked: true, skipCallLog: false, blockMode: 'reject',
    rules: [
      { id: 'r1', type: 'prefix', value: '024', label: 'Máy bàn Hà Nội (024)', on: true },
      { id: 'r2', type: 'prefix', value: '028', label: 'Máy bàn TP.HCM (028)', on: true },
      { id: 'r3', type: 'landline_all', value: '02', label: 'Tất cả máy bàn (02x)', on: false },
    ],
    blacklist: [{ number: '0869999888', label: 'Mời mua bảo hiểm' }],
    whitelist: [{ number: '02873001234', label: 'Ngân hàng – CSKH' }],
  };
  const H = 3600e3, now = Date.now();
  let log = native ? [] : [
    { number: '02462851234', t: now - 0.4 * H }, { number: '0912345678', t: now - 1.1 * H },
    { number: '0353456789', t: now - 2.5 * H }, { number: '02839991234', t: now - 3.2 * H },
    { number: '+447700900123', t: now - 26 * H }, { number: '0869999888', t: now - 28 * H }, { number: '19001234', t: now - 30 * H },
  ].map((x) => ({ ...x, ...E.decide(x.number, contactOf(x.number), cfg) }));
  let logFilter = 'all';

  // ---------- Dữ liệu thật trong app ----------
  function loadNative() {
    if (!native) return;
    try { cfg = JSON.parse(native.getConfig()); } catch (e) {}
    try {
      log = JSON.parse(native.getLog()).map((x) => ({ ...x, info: E.identify(x.number), contactName: x.contactName || null }));
    } catch (e) { log = []; }
  }
  function save() { if (native) native.saveConfig(JSON.stringify(cfg)); }
  loadNative();

  function contactOf(num) {
    if (native) { const n = native.contactName(String(num || '')); return n || null; }
    const n = E.normalize(num);
    const c = CONTACTS.find((x) => E.normalize(x.number) === n);
    return c ? c.name : null;
  }

  // ---------- Tiện ích ----------
  function toast(msg) { const t = $('toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('on'), 2400); }
  const ACT = { block: { ic: '🚫', txt: 'Đã chặn' }, warn: { ic: '⚠️', txt: 'Cảnh báo' }, allow: { ic: '✅', txt: 'Cho phép' } };
  function hm(t) { return new Date(t).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }); }
  function dayLabel(t) {
    const d = new Date(t), today = new Date(); const y = new Date(today - 864e5);
    if (d.toDateString() === today.toDateString()) return 'Hôm nay';
    if (d.toDateString() === y.toDateString()) return 'Hôm qua';
    return d.toLocaleDateString('vi-VN');
  }

  // ---------- Tabs ----------
  const TITLES = { home: 'Chặn Cuộc Gọi', log: 'Nhật ký cuộc gọi', rules: 'Quy tắc chặn', lookup: 'Tra cứu số' };
  document.querySelectorAll('.tabs button').forEach((b) => b.addEventListener('click', () => showTab(b.dataset.t)));
  function showTab(t) {
    document.querySelectorAll('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.t === t));
    document.querySelectorAll('.tab').forEach((s) => s.classList.toggle('hidden', s.id !== 'tab-' + t));
    $('pageTitle').textContent = TITLES[t];
    window.scrollTo(0, 0);
    renderAll();
  }

  // ---------- Render ----------
  function renderAll() { renderHome(); renderLog(); renderRules(); syncSwitches(); }

  function renderHome() {
    const today = new Date().toDateString();
    $('stBlock').textContent = log.filter((x) => x.action === 'block' && new Date(x.t).toDateString() === today).length;
    $('stWarn').textContent = log.filter((x) => x.action === 'warn' && new Date(x.t).toDateString() === today).length;
    renderPerms();
  }

  function renderPerms() {
    const st = native ? JSON.parse(native.permState()) : { screening: true, contacts: true, notif: true, overlay: true, battery: true, xiaomi: true };
    const cc = native ? native.contactCount() : CONTACTS.length;
    const items = [
      ['screening', 'Quyền sàng lọc cuộc gọi', 'Bắt buộc – để kiểm tra cuộc gọi trước khi đổ chuông', true],
      ['contacts', 'Đọc danh bạ', st.contacts ? `${cc} liên hệ${native ? '' : ' (mẫu)'}` : 'Để biết số nào là số quen', true],
      ['notif', 'Hiện thông báo', 'Cảnh báo số lạ, báo cuộc gọi bị chặn', true],
      ['overlay', 'Hiển thị trên ứng dụng khác', 'Thẻ cảnh báo nổi trên màn hình cuộc gọi', false],
    ];
    $('permList').innerHTML = items.map(([k, t, s, req]) => {
      const ok = !!st[k];
      return `<div class="perm" data-perm="${ok ? '' : k}"><span class="dot ${ok ? 'ok' : req ? 'bad' : 'opt'}"></span>
        <div class="pt">${t}<small>${s}</small></div>
        <span class="pv ${ok ? '' : req ? 'bad' : 'opt'}">${ok ? 'Đã cấp' : 'Cấp quyền'}</span></div>`;
    }).join('');
    const protectedOk = st.screening;
    $('statusCard').classList.toggle('ok', protectedOk);
    $('statusCard').classList.toggle('bad', !protectedOk);
    $('statusCard').querySelector('.st-title').textContent = protectedOk ? 'Đang bảo vệ' : 'Chưa bảo vệ';
    $('statusCard').querySelector('.st-sub').textContent = protectedOk
      ? (st.contacts ? 'Mọi cuộc gọi đến đều được kiểm tra trước khi đổ chuông' : 'Đang chặn theo quy tắc – cấp quyền danh bạ để nhận biết số quen')
      : 'Bấm "Cấp quyền" ở mục Quyền sàng lọc cuộc gọi bên dưới';
    $('statusCard').querySelector('.shield').textContent = protectedOk ? '🛡️' : '⚠️';
    // Xiaomi / HyperOS
    $('xiaomiCard').classList.toggle('hidden', !st.xiaomi);
    if (st.xiaomi) {
      const xm = [
        ['autostart', 'Tự khởi động', 'Bảo mật → Quyền → Tự khởi động → bật', null],
        ['battery', 'Không giới hạn pin', 'Tiết kiệm pin → Không hạn chế', st.battery],
        ['miui_perms', 'Quyền khác của HyperOS', 'Bật "Hiện cửa sổ bật lên khi chạy nền" và "Hiện trên màn hình khoá"', null],
      ];
      $('xiaomiList').innerHTML = xm.map(([k, t, s, ok]) => `<div class="xm"><div class="pt">${t}<small>${s}</small></div>
        ${ok ? '<span class="okt">✓ Đã bật</span>' : `<button data-perm="${k}">Mở cài đặt</button>`}</div>`).join('');
    }
  }
  document.addEventListener('click', (e) => {
    const p = e.target.closest('[data-perm]');
    if (!p || !p.dataset.perm) return;
    if (native) native.requestPerm(p.dataset.perm);
    else toast('(Bản xem trước) App thật sẽ mở màn hình cấp quyền');
  });

  const SIM = [
    ['024 6285 1234', 'Máy bàn HN'], ['028 3999 1234', 'Máy bàn HCM'], ['0236 3822 111', 'Máy bàn ĐN'],
    ['0912 345 678', 'Mẹ (danh bạ)'], ['024 3812 3456', 'Cty ABC (danh bạ)'], ['0353 456 789', 'Viettel lạ'],
    ['0869 999 888', 'Số đã chặn'], ['1900 1234', 'Tổng đài 1900'], ['+44 7700 900123', 'Nước ngoài'], ['', 'Số ẩn'],
  ];
  if (native) for (let i = SIM.length - 1; i >= 0; i--) if (SIM[i][1].includes('(danh bạ)')) SIM.splice(i, 1);   // danh bạ mẫu chỉ có ở bản xem trước
  $('simChips').innerHTML = SIM.map(([n, l], i) => `<button class="chip" data-i="${i}">${esc(l)}</button>`).join('');
  $('simChips').addEventListener('click', (e) => { const b = e.target.closest('.chip'); if (b) { const n = SIM[+b.dataset.i][0]; $('simInput').value = n; simulate(n); } });
  $('simGo').addEventListener('click', () => simulate($('simInput').value));
  $('simInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') simulate($('simInput').value); });

  function renderLog() {
    const items = log.filter((x) => logFilter === 'all' || x.action === logFilter).sort((a, b) => b.t - a.t);
    if (!items.length) { $('logList').innerHTML = '<div class="empty">Chưa có cuộc gọi nào</div>'; return; }
    let html = '', cur = '';
    items.forEach((x) => {
      const d = dayLabel(x.t);
      if (d !== cur) { if (cur) html += '</div>'; html += `<div class="day">${d}</div><div class="log">`; cur = d; }
      const name = x.contactName || E.format(x.number);
      html += `<div class="row" data-idx="${log.indexOf(x)}"><div class="ic ${x.action}">${ACT[x.action].ic}</div>
        <div class="mid"><div class="t1">${esc(name)}<span class="badge ${x.action}">${ACT[x.action].txt}</span></div>
        <div class="t2">${esc(x.contactName ? E.format(x.number) + ' · ' : '')}${esc(x.info.label)}${x.reason ? ' · ' + esc(x.reason) : ''}</div></div>
        <div class="time">${hm(x.t)}</div></div>`;
    });
    $('logList').innerHTML = html + '</div><div style="text-align:center;margin:16px 0"><button class="btn ghost" id="clearLog" style="height:40px">Xoá nhật ký</button></div>';
    $('clearLog').onclick = () => { if (native) native.clearLog(); log = []; renderAll(); toast('Đã xoá nhật ký'); };
  }
  $('logFilters').addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    logFilter = b.dataset.f;
    $('logFilters').querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b));
    renderLog();
  });
  $('logList').addEventListener('click', (e) => { const r = e.target.closest('.row'); if (r) numberSheet(log[+r.dataset.idx].number); });

  function renderRules() {
    save();
    $('ruleList').innerHTML = cfg.rules.length ? cfg.rules.map((r) => `
      <div class="row"><div class="ic">${r.type === 'landline_all' ? '🏢' : '🔢'}</div>
        <div class="mid"><div class="t1">${esc(r.label)}</div><div class="t2">${r.type === 'landline_all' ? 'Mọi số bắt đầu bằng 02' : 'Bắt đầu bằng ' + esc(r.value)}</div></div>
        <label class="sw-row" style="border:0;padding:0"><input type="checkbox" data-rid="${r.id}" ${r.on ? 'checked' : ''}><i></i></label>
        ${r.type === 'prefix' ? `<button class="x" data-del="${r.id}" aria-label="Xoá">×</button>` : ''}
      </div>`).join('') : '<div class="empty">Chưa có quy tắc</div>';
    const list = (arr, kind) => arr.length ? arr.map((x, i) => `
      <div class="row"><div class="ic ${kind === 'bl' ? 'block' : 'allow'}">${kind === 'bl' ? '🚫' : '✅'}</div>
        <div class="mid"><div class="t1">${esc(E.format(x.number))}</div><div class="t2">${esc(x.label || E.identify(x.number).label)}</div></div>
        <button class="x" data-${kind}="${i}" aria-label="Xoá">×</button></div>`).join('') : '<div class="empty">Trống – thêm từ Nhật ký hoặc Tra cứu</div>';
    $('blackList').innerHTML = list(cfg.blacklist, 'bl');
    $('whiteList').innerHTML = list(cfg.whitelist, 'wl');
    $('blCount').textContent = cfg.blacklist.length;
    $('wlCount').textContent = cfg.whitelist.length;
    document.querySelectorAll('#blockMode button').forEach((b) => b.classList.toggle('on', b.dataset.v === cfg.blockMode));
    // gợi ý thêm nhanh
    const sug = [['024', 'Hà Nội'], ['028', 'TP.HCM'], ['0236', 'Đà Nẵng'], ['0225', 'Hải Phòng'], ['0292', 'Cần Thơ'], ['1900', 'Tổng đài 1900']]
      .filter(([p]) => !cfg.rules.some((r) => r.value === p));
    $('ruleChips').innerHTML = sug.map(([p, l]) => `<button class="chip" data-p="${p}" data-l="${l}">+ ${p} ${l}</button>`).join('');
  }

  $('ruleList').addEventListener('change', (e) => {
    const id = e.target.dataset.rid; if (!id) return;
    const r = cfg.rules.find((x) => x.id === id); r.on = e.target.checked;
    toast(`${r.on ? 'Đã bật' : 'Đã tắt'}: ${r.label}`); syncSwitches();
  });
  $('ruleList').addEventListener('click', (e) => {
    const id = e.target.dataset.del; if (!id) return;
    cfg.rules = cfg.rules.filter((x) => x.id !== id); renderRules(); toast('Đã xoá quy tắc');
  });
  function addRule(p, label) {
    const v = E.normalize(p);
    if (!/^\+?\d{2,}$/.test(v)) { toast('Nhập đầu số ít nhất 2 chữ số'); return; }
    if (cfg.rules.some((r) => r.value === v)) { toast('Đầu số này đã có'); return; }
    const info = E.identify(v + '0000000');
    const lbl = label ? `${label} (${v})` : (info.type === 'landline' && info.area ? `Máy bàn ${info.area} (${v})` : `Đầu số ${v}`);
    cfg.rules.push({ id: 'r' + Date.now(), type: 'prefix', value: v, label: lbl, on: true });
    renderRules(); toast('Đã thêm: ' + lbl);
  }
  $('ruleAdd').addEventListener('click', () => { addRule($('ruleInput').value); $('ruleInput').value = ''; });
  $('ruleChips').addEventListener('click', (e) => { const b = e.target.closest('.chip'); if (b) addRule(b.dataset.p, b.dataset.l === 'Tổng đài 1900' ? 'Tổng đài 1900' : 'Máy bàn ' + b.dataset.l); });
  ['blackList', 'whiteList'].forEach((id) => $(id).addEventListener('click', (e) => {
    const bl = e.target.dataset.bl, wl = e.target.dataset.wl;
    if (bl != null) { cfg.blacklist.splice(+bl, 1); toast('Đã bỏ chặn'); }
    else if (wl != null) { cfg.whitelist.splice(+wl, 1); toast('Đã xoá khỏi danh sách cho phép'); }
    else return;
    renderRules();
  }));
  $('blockMode').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) { cfg.blockMode = b.dataset.v; renderRules(); } });

  // Công tắc dùng chung (có ở nhiều tab)
  function syncSwitches() {
    save();
    document.querySelectorAll('input[data-cfg]').forEach((i) => { i.checked = !!cfg[i.dataset.cfg]; });
    document.querySelectorAll('input[data-rule]').forEach((i) => { const r = cfg.rules.find((x) => x.type === i.dataset.rule); i.checked = !!(r && r.on); });
    document.querySelectorAll('input[data-cfg="allowServices"]').forEach((i) => i.closest('.sw-row').classList.toggle('dis', !cfg.blockAllUnknown));
  }
  document.addEventListener('change', (e) => {
    const k = e.target.dataset.cfg, rt = e.target.dataset.rule;
    if (k) { cfg[k] = e.target.checked; syncSwitches(); }
    if (rt) { const r = cfg.rules.find((x) => x.type === rt); if (r) r.on = e.target.checked; renderRules(); syncSwitches(); toast(`${e.target.checked ? 'Đã bật' : 'Đã tắt'}: ${r.label}`); }
  });

  // ---------- Bảng thao tác cho 1 số ----------
  function numberSheet(num) {
    const n = E.normalize(num), info = E.identify(num), cname = contactOf(num);
    const inBl = cfg.blacklist.some((x) => E.normalize(x.number) === n), inWl = cfg.whitelist.some((x) => E.normalize(x.number) === n);
    $('sheetBody').innerHTML = `<div class="h">${esc(cname || E.format(num))}</div>
      <div class="d">${esc(cname ? E.format(num) + ' · ' : '')}${info.icon} ${esc(info.label)}</div>
      ${n ? `${inBl ? '<button class="act" data-a="unblock"><span>↩️</span>Bỏ chặn số này</button>' : '<button class="act" data-a="block"><span>🚫</span>Chặn số này</button>'}
      ${inWl ? '<button class="act" data-a="unallow"><span>↩️</span>Bỏ khỏi danh sách cho phép</button>' : '<button class="act" data-a="allow"><span>✅</span>Luôn cho phép số này</button>'}
      ${info.type === 'landline' || info.type === 'mobile' ? `<button class="act" data-a="prefix"><span>🔢</span>Chặn cả đầu số ${esc(info.code || n.slice(0, 3))}</button>` : ''}
      <button class="act" data-a="lookup"><span>🔎</span>Tra cứu</button>
      <button class="act" data-a="copy"><span>📋</span>Sao chép số</button>
      ${native ? '<button class="act" data-a="dial"><span>📞</span>Gọi lại</button>' : ''}` : '<div class="empty">Số ẩn – chỉ có thể chặn bằng quy tắc "Chặn số ẩn"</div>'}`;
    $('sheet').classList.remove('hidden');
    $('sheetBody').onclick = (e) => {
      const a = e.target.closest('.act')?.dataset.a; if (!a) return;
      $('sheet').classList.add('hidden');
      if (a === 'block') { cfg.blacklist.push({ number: n, label: '' }); cfg.whitelist = cfg.whitelist.filter((x) => E.normalize(x.number) !== n); toast('Đã chặn ' + E.format(n)); }
      if (a === 'unblock') { cfg.blacklist = cfg.blacklist.filter((x) => E.normalize(x.number) !== n); toast('Đã bỏ chặn'); }
      if (a === 'allow') { cfg.whitelist.push({ number: n, label: '' }); cfg.blacklist = cfg.blacklist.filter((x) => E.normalize(x.number) !== n); toast('Số này sẽ luôn đổ chuông'); }
      if (a === 'unallow') { cfg.whitelist = cfg.whitelist.filter((x) => E.normalize(x.number) !== n); toast('Đã bỏ khỏi danh sách cho phép'); }
      if (a === 'prefix') addRule(info.code || n.slice(0, 3));
      if (a === 'lookup') { showTab('lookup'); $('lkInput').value = E.format(n); lookup(n); }
      if (a === 'copy') { if (native) native.copy(n); else { try { navigator.clipboard.writeText(n); } catch (er) {} toast('Đã sao chép ' + n); } }
      if (a === 'dial' && native) native.dial(n);
      renderAll();
    };
  }
  $('sheet').addEventListener('click', (e) => { if (e.target === $('sheet')) $('sheet').classList.add('hidden'); });

  // ---------- Tra cứu ----------
  function lookup(num) {
    if (!String(num).trim()) { $('lkResult').innerHTML = ''; return; }
    const n = E.normalize(num), info = E.identify(num), cname = contactOf(num), d = E.decide(num, cname, cfg);
    const vtxt = { block: '🚫 Số này sẽ bị CHẶN', warn: '⚠️ Số này sẽ đổ chuông kèm CẢNH BÁO', allow: '✅ Số này được phép gọi' }[d.action];
    $('lkResult').innerHTML = `<div class="lk"><div class="big">${esc(E.format(num))}</div>
      <div class="kv"><span>Loại số</span><span>${info.icon} ${esc(info.label)}</span></div>
      ${info.carrier ? `<div class="kv"><span>Nhà mạng (theo đầu số)</span><span>${esc(info.carrier)}</span></div>` : ''}
      ${info.area ? `<div class="kv"><span>Tỉnh / thành phố</span><span>${esc(info.area)}</span></div>` : ''}
      <div class="kv"><span>Danh bạ</span><span>${cname ? '👤 ' + esc(cname) : 'Không có'}</span></div>
      <div class="verdict ${d.action}">${vtxt}${d.reason ? `<small>${esc(d.reason)}</small>` : ''}</div>
      <div class="btns"><button class="btn red" id="lkBlock">Chặn số này</button><button class="btn ghost" id="lkAllow">Luôn cho phép</button></div>
      <div class="card-sub" style="margin:10px 0 0">Nhà mạng xác định theo đầu số; số đã chuyển mạng giữ số có thể thuộc mạng khác.</div></div>`;
    $('lkBlock').onclick = () => { if (!n) return; cfg.blacklist.push({ number: n, label: '' }); cfg.whitelist = cfg.whitelist.filter((x) => E.normalize(x.number) !== n); toast('Đã chặn ' + E.format(n)); lookup(num); };
    $('lkAllow').onclick = () => { if (!n) return; cfg.whitelist.push({ number: n, label: '' }); cfg.blacklist = cfg.blacklist.filter((x) => E.normalize(x.number) !== n); toast('Số này sẽ luôn đổ chuông'); lookup(num); };
  }
  $('lkGo').addEventListener('click', () => lookup($('lkInput').value));
  $('lkInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') lookup($('lkInput').value); });

  // ---------- Giả lập cuộc gọi đến ----------
  function simulate(num) {
    const cname = contactOf(num);
    const d = E.decide(num, cname, cfg);
    if (!native) log.push({ number: E.normalize(num), t: Date.now(), ...d });
    const shown = E.format(num);
    const cs = $('callScreen');
    if (d.action === 'block') {
      cs.innerHTML = `<div class="blocked-view"><div class="big">🔕</div><div class="h">Máy không đổ chuông</div>
          <div class="sub">${cfg.blockMode === 'reject' ? 'Cuộc gọi đã bị từ chối – người gọi nghe máy bận' : 'Cuộc gọi bị im lặng – người gọi nghe chuông chờ'}</div></div>
        ${cfg.notifyBlocked ? `<div class="notif"><div class="app">🛡️ Chặn Cuộc Gọi · bây giờ</div>
          <div class="h">Đã chặn cuộc gọi từ ${esc(shown)}</div><div class="d">${esc(d.info.label)} · ${esc(d.reason)}</div>
          <div class="na"><button data-a="unblock">Bỏ chặn số này</button><button data-a="close">Đóng</button></div></div>`
          : '<div class="sub" style="margin-top:20px">(Đã tắt thông báo khi chặn – chỉ ghi vào Nhật ký)</div>'}
        <button class="close" data-a="close">Đóng giả lập</button>`;
    } else {
      const unknown = d.action === 'warn';
      cs.innerHTML = `${unknown ? `<div class="alert-card"><div class="app">🛡️ Chặn Cuộc Gọi</div>
          <div class="h">⚠️ Số lạ – không có trong danh bạ</div>
          <div class="d"><b>${esc(shown)}</b><br>${d.info.icon} ${esc(d.info.label)}</div></div>` : ''}
        <div class="avatar">${cname ? esc(cname.trim()[0].toUpperCase()) : d.info.icon}</div>
        <div class="who">${esc(cname || shown)}</div>
        <div class="num">${esc(cname ? shown : d.info.label)}</div>
        ${d.reason === 'Có trong danh bạ' ? '' : (d.reason ? `<div class="sub">${esc(d.reason)}</div>` : '')}
        <div class="ring">Cuộc gọi đến…</div>
        <div class="actions"><button class="dec" data-a="close">✆</button><button class="acc" data-a="close">✆</button></div>
        ${unknown ? '<button class="close" data-a="blocknum">🚫 Chặn số này</button>' : ''}
        <button class="close" data-a="close">Đóng giả lập</button>`;
    }
    cs.classList.remove('hidden');
    cs.onclick = (e) => {
      const a = e.target.closest('[data-a]')?.dataset.a; if (!a) return;
      const n = E.normalize(num);
      if (a === 'unblock' && n) { cfg.blacklist = cfg.blacklist.filter((x) => E.normalize(x.number) !== n); cfg.whitelist.push({ number: n, label: '' }); toast('Số này sẽ luôn đổ chuông'); }
      if (a === 'blocknum' && n) { cfg.blacklist.push({ number: n, label: '' }); toast('Đã chặn ' + E.format(n)); }
      cs.classList.add('hidden');
      renderAll();
    };
    renderAll();
  }

  window.App = {
    refresh() { loadNative(); renderAll(); },
    back() {
      if (!$('callScreen').classList.contains('hidden')) { $('callScreen').classList.add('hidden'); return true; }
      if (!$('sheet').classList.contains('hidden')) { $('sheet').classList.add('hidden'); return true; }
      if (!$('tab-home').classList.contains('hidden')) return false;
      showTab('home'); return true;
    },
  };

  renderAll();
})();
