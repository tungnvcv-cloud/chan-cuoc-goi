package vn.dang.callguard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat

/** Xử lý nút trong thông báo: "Chặn số này" / "Bỏ chặn số này" */
class ActionReceiver : BroadcastReceiver() {
    companion object {
        const val BLOCK = "vn.dang.callguard.BLOCK"
        const val ALLOW = "vn.dang.callguard.ALLOW"
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        val number = intent.getStringExtra("number") ?: return
        when (intent.action) {
            BLOCK -> { Store.putNumber(ctx, "blacklist", number); Toast.makeText(ctx, "Đã chặn ${Engine.format(number)}", Toast.LENGTH_SHORT).show() }
            ALLOW -> { Store.putNumber(ctx, "whitelist", number); Toast.makeText(ctx, "${Engine.format(number)} sẽ luôn đổ chuông", Toast.LENGTH_SHORT).show() }
        }
        Alerts.hideOverlay(ctx)
        val id = intent.getIntExtra("notifId", 0)
        if (id != 0) NotificationManagerCompat.from(ctx).cancel(id)
    }
}
