package vn.dang.callguard

import android.Manifest
import android.annotation.SuppressLint
import android.app.role.RoleManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var pageReady = false

    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { refresh() }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }
    private val settingsLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { refresh() }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Alerts.createChannels(this)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.setSupportZoom(false)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) { pageReady = true }
            }
            addJavascriptInterface(Bridge(), "Android")
        }
        setContentView(buildRoot())
        web.loadUrl("file:///android_asset/ui/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.App ? App.back() : false") { r -> if (r != "true") finish() }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        if (pageReady) web.evaluateJavascript("window.App && App.refresh()", null)
    }

    /** Chừa vùng thanh trạng thái & thanh điều hướng (Android 15+/HyperOS vẽ tràn màn hình) */
    private fun buildRoot(): View {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val topBar = View(this).apply { setBackgroundColor(Color.parseColor("#0F766E")) }
        val bottomBar = View(this).apply { setBackgroundColor(Color.WHITE) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            addView(topBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0))
            addView(web, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(bottomBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            topBar.layoutParams = topBar.layoutParams.apply { height = bars.top }
            bottomBar.layoutParams = bottomBar.layoutParams.apply { height = bars.bottom }
            v.setPadding(bars.left, 0, bars.right, 0)
            topBar.requestLayout()
            WindowInsetsCompat.CONSUMED
        }
        WindowCompat.getInsetsController(window, root).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = true
        }
        return root
    }

    private val isXiaomi: Boolean
        get() = Build.MANUFACTURER.equals("Xiaomi", true) || Build.BRAND.lowercase() in setOf("xiaomi", "redmi", "poco")

    private fun roleHeld(): Boolean {
        val rm = getSystemService(RoleManager::class.java) ?: return false
        return rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) && rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun tryStart(vararg intents: Intent) {
        for (i in intents) {
            try { settingsLauncher.launch(i); return } catch (_: Exception) { }
        }
        Toast.makeText(this, "Không mở được cài đặt, hãy vào Cài đặt → Ứng dụng → Chặn Cuộc Gọi", Toast.LENGTH_LONG).show()
    }

    private fun appDetails() = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))

    inner class Bridge {
        @JavascriptInterface fun getConfig(): String = Store.config(this@MainActivity).toString()
        @JavascriptInterface fun saveConfig(json: String) { try { Store.saveConfig(this@MainActivity, json) } catch (_: Exception) { } }
        @JavascriptInterface fun getLog(): String = Store.log(this@MainActivity).toString()
        @JavascriptInterface fun clearLog() = Store.clearLog(this@MainActivity)
        @JavascriptInterface fun contactName(number: String): String = Store.contactName(this@MainActivity, number) ?: ""
        @JavascriptInterface fun contactCount(): Int = Store.contactCount(this@MainActivity)
        @JavascriptInterface fun isXiaomi(): Boolean = this@MainActivity.isXiaomi

        @JavascriptInterface
        fun permState(): String {
            val pm = getSystemService(PowerManager::class.java)
            return JSONObject()
                .put("screening", roleHeld())
                .put("contacts", granted(Manifest.permission.READ_CONTACTS))
                .put("notif", Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS))
                .put("overlay", Settings.canDrawOverlays(this@MainActivity))
                .put("battery", pm?.isIgnoringBatteryOptimizations(packageName) == true)
                .put("xiaomi", isXiaomi)
                .toString()
        }

        @JavascriptInterface
        fun requestPerm(key: String) = runOnUiThread {
            when (key) {
                "screening" -> {
                    val rm = getSystemService(RoleManager::class.java)
                    if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
                    else Toast.makeText(this@MainActivity, "Máy không hỗ trợ sàng lọc cuộc gọi (cần Android 10+)", Toast.LENGTH_LONG).show()
                }
                "contacts" -> permLauncher.launch(arrayOf(Manifest.permission.READ_CONTACTS))
                "notif" -> if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
                "overlay" -> tryStart(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), appDetails())
                "battery" -> tryStart(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")),
                    Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS), appDetails())
                "autostart" -> tryStart(
                    Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
                    appDetails())
                "miui_perms" -> tryStart(
                    Intent("miui.intent.action.APP_PERM_EDITOR")
                        .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
                        .putExtra("extra_pkgname", packageName),
                    appDetails())
                "app" -> tryStart(appDetails())
            }
        }

        @JavascriptInterface
        fun copy(text: String) = runOnUiThread {
            getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("số điện thoại", text))
            Toast.makeText(this@MainActivity, "Đã sao chép $text", Toast.LENGTH_SHORT).show()
        }

        @JavascriptInterface
        fun dial(number: String) = runOnUiThread {
            try { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))) } catch (_: Exception) { }
        }
    }
}
