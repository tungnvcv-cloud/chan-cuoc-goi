package vn.dang.callguard

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/** Thông báo & thẻ cảnh báo nổi trên màn hình cuộc gọi */
object Alerts {
    const val CH_WARN = "warn_unknown"
    const val CH_BLOCK = "blocked_calls"
    private var overlay: View? = null
    private val main = Handler(Looper.getMainLooper())

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CH_WARN, "Cảnh báo số lạ", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Hiện khi có cuộc gọi từ số không có trong danh bạ"
            setSound(null, null)   // máy đã đổ chuông cuộc gọi, không kêu thêm
            enableVibration(false)
        })
        nm.createNotificationChannel(NotificationChannel(CH_BLOCK, "Cuộc gọi bị chặn", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Thông báo nhỏ mỗi lần chặn cuộc gọi"
        })
    }

    private fun canNotify(ctx: Context) =
        (Build.VERSION.SDK_INT < 33 || ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) &&
            NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    private fun openAppIntent(ctx: Context) = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun action(ctx: Context, act: String, number: String, notifId: Int): PendingIntent {
        val i = Intent(ctx, ActionReceiver::class.java).setAction(act).putExtra("number", number).putExtra("notifId", notifId)
        return PendingIntent.getBroadcast(ctx, (act + number).hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    /** Số lạ gọi đến: thẻ nổi (nếu được phép hiển thị trên app khác) + thông báo heads-up */
    @SuppressLint("MissingPermission")
    fun warnUnknown(ctx: Context, number: String, d: Engine.Decision) {
        val shown = Engine.format(number)
        if (Settings.canDrawOverlays(ctx)) main.post { showOverlay(ctx, number, shown, d.info.label) }
        if (!canNotify(ctx)) return
        createChannels(ctx)
        val id = 1000 + (number.hashCode() and 0xfff)
        val n = NotificationCompat.Builder(ctx, CH_WARN)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("⚠️ Số lạ: $shown")
            .setContentText("${d.info.label} · Không có trong danh bạ")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setColor(Color.parseColor("#D97706"))
            .setAutoCancel(true)
            .setTimeoutAfter(60_000)
            .setContentIntent(openAppIntent(ctx))
            .addAction(0, "Chặn số này", action(ctx, ActionReceiver.BLOCK, number, id))
            .build()
        NotificationManagerCompat.from(ctx).notify(id, n)
    }

    @SuppressLint("MissingPermission")
    fun notifyBlocked(ctx: Context, number: String, d: Engine.Decision) {
        if (!canNotify(ctx)) return
        createChannels(ctx)
        val id = 2000 + (number.hashCode() and 0xfff)
        val n = NotificationCompat.Builder(ctx, CH_BLOCK)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("Đã chặn cuộc gọi từ ${Engine.format(number)}")
            .setContentText("${d.info.label} · ${d.reason}")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setColor(Color.parseColor("#0F766E"))
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(ctx))
            .apply { if (number.isNotEmpty()) addAction(0, "Bỏ chặn số này", action(ctx, ActionReceiver.ALLOW, number, id)) }
            .build()
        NotificationManagerCompat.from(ctx).notify(id, n)
    }

    private fun dp(ctx: Context, v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, ctx.resources.displayMetrics).toInt()

    /** Thẻ cảnh báo màu vàng phía trên màn hình cuộc gọi; chạm để đóng, tự ẩn sau 25 giây */
    private fun showOverlay(ctx: Context, number: String, shown: String, label: String) {
        try {
            hideOverlay(ctx)
            val wm = ctx.getSystemService(WindowManager::class.java) ?: return
            val card = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(ctx, 16f), dp(ctx, 12f), dp(ctx, 16f), dp(ctx, 12f))
                background = GradientDrawable().apply {
                    cornerRadius = dp(ctx, 16f).toFloat()
                    setColor(Color.parseColor("#FFFBEB"))
                    setStroke(dp(ctx, 2f), Color.parseColor("#F59E0B"))
                }
                elevation = dp(ctx, 8f).toFloat()
            }
            fun tv(text: String, size: Float, bold: Boolean, color: String) = TextView(ctx).apply {
                this.text = text
                setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
                setTextColor(Color.parseColor(color))
                if (bold) typeface = Typeface.DEFAULT_BOLD
            }
            card.addView(tv("🛡️ Chặn Cuộc Gọi   ·   chạm để đóng", 11f, false, "#92400E"))
            card.addView(tv("⚠️ Số lạ – không có trong danh bạ", 16f, true, "#78350F"))
            card.addView(tv(shown, 18f, true, "#111827"))
            card.addView(tv(label, 14f, false, "#78350F"))
            val wrap = LinearLayout(ctx).apply {
                setPadding(dp(ctx, 12f), dp(ctx, 40f), dp(ctx, 12f), 0)
                addView(card, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
                setOnClickListener { hideOverlay(ctx) }
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP }
            wm.addView(wrap, lp)
            overlay = wrap
            main.postDelayed({ hideOverlay(ctx) }, 25_000)
        } catch (_: Exception) { }
    }

    fun hideOverlay(ctx: Context) {
        val v = overlay ?: return
        overlay = null
        try { ctx.getSystemService(WindowManager::class.java)?.removeView(v) } catch (_: Exception) { }
    }
}
