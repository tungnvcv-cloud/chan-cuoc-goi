package vn.dang.callguard

import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.TelecomManager

/**
 * Android gọi vào đây cho MỌI cuộc gọi đến, trước khi máy đổ chuông
 * (app phải được chọn làm "ứng dụng sàng lọc cuộc gọi"). Phải trả lời trong 5 giây.
 */
class ScreeningService : CallScreeningService() {

    override fun onScreenCall(details: Call.Details) {
        if (details.callDirection != Call.Details.DIRECTION_INCOMING) {
            respondToCall(details, CallResponse.Builder().build())
            return
        }
        val ctx = applicationContext
        val hidden = details.handlePresentation != TelecomManager.PRESENTATION_ALLOWED
        val raw = if (hidden) "" else (details.handle?.schemeSpecificPart ?: "")
        val response = CallResponse.Builder()
        var decision: Engine.Decision? = null
        var contact: String? = null
        try {
            val cfg = Store.config(ctx)
            contact = Store.contactName(ctx, raw)
            val d = Engine.decide(raw, contact, cfg)
            decision = d
            if (d.action == "block") {
                if (cfg.optString("blockMode") == "silent") {
                    // Im lặng: không đổ chuông nhưng cuộc gọi vẫn chờ, người gọi nghe chuông chờ
                    response.setSilenceCall(true)
                } else {
                    response.setDisallowCall(true)
                        .setRejectCall(true)
                        .setSkipNotification(true)
                        .setSkipCallLog(cfg.optBoolean("skipCallLog"))
                }
            }
        } catch (_: Exception) {
            // lỗi bất kỳ -> cho cuộc gọi đi qua bình thường
        }
        respondToCall(details, response.build())

        // Ghi nhật ký & cảnh báo sau khi đã trả lời hệ thống
        val d = decision ?: return
        try {
            val number = Engine.normalize(raw)
            Store.addLog(ctx, number, d, contact)
            val cfg = Store.config(ctx)
            when (d.action) {
                "warn" -> Alerts.warnUnknown(ctx, number, d)
                "block" -> if (cfg.optBoolean("notifyBlocked", true)) Alerts.notifyBlocked(ctx, number, d)
            }
        } catch (_: Exception) { }
    }
}
