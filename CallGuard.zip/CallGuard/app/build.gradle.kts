plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "vn.dang.callguard"
    compileSdk = 35

    defaultConfig {
        applicationId = "vn.dang.callguard"
        minSdk = 29          // Android 10+ (API sàng lọc cuộc gọi cho app thường)
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    // Khoá ký cố định để cài đè bản mới không phải gỡ bản cũ
    signingConfigs {
        create("release") {
            storeFile = file("release.jks")
            storePassword = "callguard123"
            keyAlias = "callguard"
            keyPassword = "callguard123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            signingConfig = signingConfigs.getByName("release")
        }
    }

    buildFeatures { buildConfig = true }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.3")
}
