# Chặn Cuộc Gọi – app Android chặn cuộc gọi rác (chỉ cuộc gọi, không tin nhắn)

- Kiểm tra mọi cuộc gọi đến TRƯỚC khi máy đổ chuông (CallScreeningService, Android 10+).
- Số trong danh bạ: đổ chuông bình thường. Số lạ: cảnh báo (thông báo + thẻ nổi).
- Chặn theo đầu số (mặc định 024, 028), tất cả máy bàn 02x, số ẩn, số nước ngoài, mọi số lạ.
- Danh sách chặn / luôn cho phép, nhật ký cuộc gọi, tra cứu nhà mạng – tỉnh theo đầu số.
- Chạy hoàn toàn trên máy, không cần mạng, không gửi danh bạ đi đâu.

Build: tải CallGuard.zip + .github/workflows/build.yml lên GitHub, tab Actions tự build APK.
Khoá ký app: app/release.jks (mật khẩu callguard123) – giữ nguyên để cài đè bản mới.
