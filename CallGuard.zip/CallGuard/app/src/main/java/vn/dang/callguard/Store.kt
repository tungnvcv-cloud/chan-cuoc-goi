package vn.dang.callguard

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import org.json.JSONArray
import org.json.JSONObject

/** Lưu cấu hình quy tắc + nhật ký cuộc gọi (SharedPreferences), tra danh bạ. */
object Store {
    private const val PREFS = "callguard"
    private const val MAX_LOG = 500

    private val DEFAULT_CFG = """
        {"warnUnknown":true,"blockHidden":false,"blockIntl":false,"blockAllUnknown":false,"allowServices":true,
         "notifyBlocked":true,"skipCallLog":false,"blockMode":"reject",
         "rules":[
           {"id":"r1","type":"prefix","value":"024","label":"Máy bàn Hà Nội (024)","on":true},
           {"id":"r2","type":"prefix","value":"028","label":"Máy bàn TP.HCM (028)","on":true},
           {"id":"r3","type":"landline_all","value":"02","label":"Tất cả máy bàn (02x)","on":false}
         ],
         "blacklist":[],"whitelist":[]}
    """.trimIndent()

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun config(ctx: Context): JSONObject =
        try { JSONObject(prefs(ctx).getString("cfg", null) ?: DEFAULT_CFG) } catch (_: Exception) { JSONObject(DEFAULT_CFG) }

    @Synchronized
    fun saveConfig(ctx: Context, json: String) {
        JSONObject(json) // kiểm tra hợp lệ
        prefs(ctx).edit().putString("cfg", json).apply()
    }

    @Synchronized
    fun log(ctx: Context): JSONArray =
        try { JSONArray(prefs(ctx).getString("log", "[]")) } catch (_: Exception) { JSONArray() }

    @Synchronized
    fun addLog(ctx: Context, number: String, d: Engine.Decision, contactName: String?) {
        val old = log(ctx)
        val out = JSONArray()
        out.put(JSONObject().put("number", number).put("t", System.currentTimeMillis()).put("action", d.action)
            .put("reason", d.reason).put("label", d.info.label).put("contactName", contactName ?: ""))
        for (i in 0 until minOf(old.length(), MAX_LOG - 1)) out.put(old.get(i))
        prefs(ctx).edit().putString("log", out.toString()).apply()
    }

    @Synchronized
    fun clearLog(ctx: Context) = prefs(ctx).edit().putString("log", "[]").apply()

    /** Thêm số vào danh sách chặn (list="blacklist") hoặc cho phép (list="whitelist"), gỡ khỏi danh sách kia */
    @Synchronized
    fun putNumber(ctx: Context, list: String, number: String) {
        val cfg = config(ctx)
        val n = Engine.normalize(number)
        if (n.isEmpty()) return
        val other = if (list == "blacklist") "whitelist" else "blacklist"
        fun without(name: String): JSONArray {
            val a = cfg.optJSONArray(name) ?: JSONArray()
            val r = JSONArray()
            for (i in 0 until a.length()) { val o = a.optJSONObject(i) ?: continue; if (Engine.normalize(o.optString("number")) != n) r.put(o) }
            return r
        }
        val target = without(list).put(JSONObject().put("number", n).put("label", ""))
        cfg.put(list, target)
        cfg.put(other, without(other))
        prefs(ctx).edit().putString("cfg", cfg.toString()).apply()
    }

    fun hasContactsPermission(ctx: Context) =
        ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    /** Tên trong danh bạ, hoặc null */
    fun contactName(ctx: Context, number: String?): String? {
        if (number.isNullOrBlank() || !hasContactsPermission(ctx)) return null
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) { null }
    }

    fun contactCount(ctx: Context): Int {
        if (!hasContactsPermission(ctx)) return -1
        return try {
            ctx.contentResolver.query(ContactsContract.Contacts.CONTENT_URI, arrayOf(ContactsContract.Contacts._ID),
                "${ContactsContract.Contacts.HAS_PHONE_NUMBER} = 1", null, null)?.use { it.count } ?: 0
        } catch (_: Exception) { 0 }
    }
}
